class Post{
  String name;
  String phoneNumber;
  String email;
  String address;
  String subject;
  String contents;
  
  Post.init(String name,String phoneNumber,String email,String address,String subject,String contents);

}