package com.example.flutter_post

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
